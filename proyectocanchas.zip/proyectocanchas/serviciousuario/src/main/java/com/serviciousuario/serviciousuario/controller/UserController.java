package com.serviciousuario.serviciousuario.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PathVariable;

import com.serviciousuario.serviciousuario.model.User;
import com.serviciousuario.serviciousuario.services.UserServices;

@RestController
@RequestMapping("/api/users")
public class UserController {
    @Autowired
    private UserServices userServices;

    @GetMapping
    public List<User> listarUsuarios() {
        return userServices.listarUsuarios();
    }

    @PostMapping
    public User crearUsuario(@RequestBody User user) {
        return userServices.crearUsuario(user);
    }

    @GetMapping("/{id}")
    public User buscarUsuarioId(@PathVariable Long id) {
        return userServices.buscarUsuarioId(id);
    }

    @GetMapping("/eliminar/{id}")
    public User eliminarUsuario(@PathVariable Long id) {
        return userServices.eliminarUsuario(id);
    }

}
