package com.serviciousuario.serviciousuario.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.serviciousuario.serviciousuario.model.User;

public interface UserRepository extends JpaRepository<User, Long> {
    
}
