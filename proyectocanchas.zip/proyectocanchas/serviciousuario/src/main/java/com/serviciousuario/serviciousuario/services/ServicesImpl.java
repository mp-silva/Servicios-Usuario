package com.serviciousuario.serviciousuario.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.serviciousuario.serviciousuario.model.User;
import com.serviciousuario.serviciousuario.repository.UserRepository;

@Service
public class ServicesImpl implements UserServices{
    @Autowired
    private UserRepository userRepository;

    @Override
    public List<User> listarUsuarios() {
        return userRepository.findAll();
    }

    @Override
    public User crearUsuario(User user) {
        return userRepository.save(user);

    }

    @Override
    public User buscarUsuarioId(Long id) {
        return userRepository.findById(id).orElse(null);
    }

    @Override
    public User eliminarUsuario(Long id) {
        User user = userRepository.findById(id).orElse(null);
        if (user != null) {
            userRepository.delete(user);
        }
        return user;
    }
}
   

    

