package com.serviciousuario.serviciousuario.services;

import java.util.List;

import com.serviciousuario.serviciousuario.model.User;

public interface UserServices {

    List<User> listarUsuarios();

    User crearUsuario(User user);

    User buscarUsuarioId(Long id);

    User eliminarUsuario(Long id);
    
}
